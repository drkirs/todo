from django.urls import path, re_path

from .views import *

urlpatterns = [
    path('', index),
    path('lists/<int:listID>/', categories),
    re_path(r'^archive/(?P<day>[0-9]{8})/', archive),
    path('about/', about, name='about'),
]