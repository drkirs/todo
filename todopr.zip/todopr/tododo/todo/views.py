from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.shortcuts import render, redirect
from .models import *

menu = ["Описание", "Добавить пункт", "Обратная связь", "Войти"]

# Create your views here.
def index(request):
    posts = Lists.objects.all()
    return render(request, 'todo/index.html', {'posts': posts, 'menu': menu, 'title': 'Главная страница'})

def about(request):
    return render(request, 'todo/about.html', {'menu': menu, 'title': 'О сайте'})

def categories(request, listID):
    return HttpResponse(f'<h1>Листы по категориям</h1><p>{listID}</p>')

def archive(request, day):
    if int(day) > 16072021:
        return redirect('/')

    return HttpResponse(f'<h1>Архив по дням</h1><p>{day}</p>')

def pageNotFound(request, exeption):
    return HttpResponseNotFound('<h1>Страница не найдена</h1>')